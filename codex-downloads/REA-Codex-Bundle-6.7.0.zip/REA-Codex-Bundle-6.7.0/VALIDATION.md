# Validation performed for this bundle

The configuration helper passed 12 isolated checks on Linux using Node 24.19.0
and the vendored smol-toml 1.9.0 parser:

1. Dry-run writes no destination configuration or skills.
2. New user-level registration/skill/guidance creation; second run makes no edits.
3. Existing provider environment, unrelated settings, comments, MCP servers and
   newer Codex per-tool approval tables survive; backup matches original bytes.
4. An unchanged configuration retains its exact original bytes, including BOM.
5. Effective AGENTS.override.md, existing global rules and unknown skill files
   survive; changed known skill files receive backups.
6. Malformed TOML blocks all planned destination changes.
7. Foreign rea registrations and existing REA aliases block duplicate registration.
8. Disabled REA entries and unrelated skill identity are not overwritten.
9. Symlink destinations are refused; the referenced file remains unchanged.
10. Malformed managed agent blocks prevent changes.
11. A different REA runtime version is not silently downgraded.
12. The CLI base64 argument transport preserves Unicode paths.

The downloaded REA 6.7.0 and smol-toml 1.9.0 npm archives passed SHA-512 integrity
verification against registry metadata over verified HTTPS. All seven upstream
released skill instruction/reference files were copied unchanged. The extra
agents/openai.yaml is authored for this bundle.

Not executed: native Windows PowerShell installer, real user profile changes,
package installation on Windows, live Codex MCP reconnection, provider readiness,
or decompilation. Test configuration used isolated temporary fixture files;
no user credentials, real Codex config, live runtime, or original repository
source files were modified.

The ZIP and per-file checksum inventory are checked after packaging. A saved
configuration and an installed skill do not establish a live MCP connection.
