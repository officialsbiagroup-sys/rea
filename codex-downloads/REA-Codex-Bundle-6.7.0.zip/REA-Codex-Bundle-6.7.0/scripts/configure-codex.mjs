import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { parse } from '../vendor/smol-toml/dist/index.js';

const bundleRoot = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const sha256 = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const markerStart = '<!-- BEGIN REA CODEX BUNDLE -->';
const markerEnd = '<!-- END REA CODEX BUNDLE -->';
const plainObject = x => x !== null && typeof x === 'object' && !Array.isArray(x);
const comparable = value => {
  if (Array.isArray(value)) return value.map(comparable);
  if (value && (Object.getPrototypeOf(value) === null || Object.getPrototypeOf(value) === Object.prototype)) {
    return Object.fromEntries(Object.keys(value).sort().map(key => [key, comparable(value[key])]));
  }
  return value;
};

function rejectLinkedPath(target) {
  let current = path.resolve(target);
  for (;;) {
    if (fs.existsSync(current) || (() => { try { fs.lstatSync(current); return true; } catch (e) { if (e.code === 'ENOENT') return false; throw e; } })()) {
      if (fs.lstatSync(current).isSymbolicLink()) throw new Error(`Linked paths are not modified: ${current}`);
    }
    const parent = path.dirname(current);
    if (parent === current) return;
    current = parent;
  }
}

function readRegular(target) {
  rejectLinkedPath(target);
  try {
    if (!fs.lstatSync(target).isFile()) throw new Error(`Expected a regular file: ${target}`);
    return fs.readFileSync(target);
  } catch (e) {
    if (e.code === 'ENOENT') return null;
    throw e;
  }
}

function sourceFiles(root) {
  const result = [];
  for (const item of fs.readdirSync(root, { withFileTypes: true })) {
    const target = path.join(root, item.name);
    if (item.isSymbolicLink()) throw new Error(`Linked bundle file: ${target}`);
    if (item.isDirectory()) result.push(...sourceFiles(target));
    else if (item.isFile()) result.push(target);
    else throw new Error(`Unsupported bundle entry: ${target}`);
  }
  return result.sort();
}

function appendTable(text, name, lines) {
  return `${text.trimEnd()}\n\n[${name}]\n${lines.join('\n')}\n`;
}

function addEnvironment(text, values, exists) {
  const lines = Object.entries(values).map(([k, v]) => `${k} = ${JSON.stringify(v)}`);
  if (!lines.length) return text;
  if (!exists) return appendTable(text, 'mcp_servers.rea.env', lines);
  // Unsupported layouts fail the complete TOML semantic check before any write.
  const match = /^\s*\[mcp_servers\.rea\.env\]\s*(?:#.*)?$/m.exec(text);
  if (!match) throw new Error('Existing REA environment uses a nonstandard TOML layout; preserve it and configure manually.');
  const start = match.index + match[0].length;
  return `${text.slice(0, start)}\n${lines.join('\n')}${text.slice(start)}`;
}

function looksLikeRea(server) {
  if (!plainObject(server)) return false;
  const command = String(server.command || '');
  const args = Array.isArray(server.args) ? server.args.map(String) : [];
  return /(?:^|[/\\])rea(?:-agents)?(?:\.cmd|\.exe)?$/i.test(command)
    || [command, ...args].some(value => /(?:^|[/\\])rea-agents(?:[/\\@]|$)/i.test(value));
}

export function configureCodex({ home, codexHome, reaRoot, nodePath, providerEnv = {}, apply = false }) {
  if (![home, codexHome, reaRoot, nodePath].every(x => typeof x === 'string' && path.isAbsolute(x))) {
    throw new Error('All installation paths must be absolute.');
  }
  const packageFile = path.join(reaRoot, 'package.json');
  const pkg = JSON.parse(readRegular(packageFile)?.toString('utf8') || 'null');
  if (pkg?.name !== 'rea-agents' || pkg?.version !== '6.7.0') {
    throw new Error('This bundle requires existing rea-agents 6.7.0; it never downgrades another version.');
  }
  const entry = path.join(reaRoot, 'scripts', 'rea.mjs');
  if (readRegular(entry) === null || readRegular(nodePath) === null) throw new Error('Node or REA entry point is missing.');
  const allowedEnv = new Set(['GHIDRA_INSTALL_DIR', 'JAVA_HOME', 'REA_ANALYSIS_PROVIDER']);
  for (const [key, value] of Object.entries(providerEnv)) {
    if (!allowedEnv.has(key) || typeof value !== 'string' || !value.length) throw new Error(`Invalid provider setting: ${key}`);
  }

  const plans = [];
  const planFile = (target, bytes) => {
    const before = readRegular(target);
    if (before === null || !before.equals(bytes)) plans.push({ target, before, bytes });
  };
  const configPath = path.join(codexHome, 'config.toml');
  const originalConfig = readRegular(configPath);
  const configText = (originalConfig || Buffer.alloc(0)).toString('utf8').replace(/^\uFEFF/, '');
  const before = parse(configText);
  if (before.mcp_servers !== undefined && !plainObject(before.mcp_servers)) throw new Error('Malformed mcp_servers table.');
  const servers = before.mcp_servers || {};
  for (const [name, server] of Object.entries(servers)) {
    if (name !== 'rea' && looksLikeRea(server)) throw new Error(`REA is already registered as ${name}; no duplicate was added.`);
  }
  let output = configText;
  let expectedServer;
  if (servers.rea !== undefined) {
    if (!looksLikeRea(servers.rea)) throw new Error('The existing rea entry is not a recognized REA stdio launcher; left unchanged.');
    if (servers.rea.enabled === false) throw new Error('The existing REA registration is disabled; enable it explicitly in Codex settings.');
    if (servers.rea.env !== undefined && !plainObject(servers.rea.env)) throw new Error('Malformed existing REA environment map.');
    const extraEnv = Object.fromEntries(Object.entries(providerEnv).filter(([k]) => servers.rea.env?.[k] === undefined));
    output = addEnvironment(output, extraEnv, servers.rea.env !== undefined);
    expectedServer = Object.keys(extraEnv).length
      ? { ...servers.rea, env: { ...servers.rea.env, ...extraEnv } }
      : servers.rea;
  } else {
    expectedServer = { command: nodePath, args: [entry, 'mcp'], startup_timeout_sec: 30, tool_timeout_sec: 450 };
    output = appendTable(output, 'mcp_servers.rea', [
      `command = ${JSON.stringify(nodePath)}`,
      `args = [${JSON.stringify(entry)}, "mcp"]`,
      'startup_timeout_sec = 30',
      'tool_timeout_sec = 450',
    ]);
    if (Object.keys(providerEnv).length) {
      output = addEnvironment(output, providerEnv, false);
      expectedServer.env = { ...providerEnv };
    }
  }
  const expected = { ...before, mcp_servers: { ...servers, rea: expectedServer } };
  if (!isDeepStrictEqual(comparable(parse(output)), comparable(expected))) throw new Error('TOML validation failed; configuration was not written.');
  // No change means preserve the original bytes, including BOM and whitespace.
  if (output !== configText) planFile(configPath, Buffer.from(output, 'utf8'));

  const sourceSkill = path.join(bundleRoot, 'skills', 'reverse-engineer-anything');
  const targetSkill = path.join(home, '.agents', 'skills', 'reverse-engineer-anything');
  const oldSkill = readRegular(path.join(targetSkill, 'SKILL.md'));
  if (oldSkill && !/^name:\s*["']?reverse-engineer-anything["']?\s*$/m.test(oldSkill.toString('utf8'))) {
    throw new Error('An unrelated skill occupies the destination; left unchanged.');
  }
  for (const source of sourceFiles(sourceSkill)) {
    planFile(path.join(targetSkill, path.relative(sourceSkill, source)), fs.readFileSync(source));
  }

  const overridePath = path.join(codexHome, 'AGENTS.override.md');
  const guidePath = readRegular(overridePath) !== null ? overridePath : path.join(codexHome, 'AGENTS.md');
  const guide = readRegular(guidePath)?.toString('utf8') || '';
  const block = `${markerStart}\n${fs.readFileSync(path.join(bundleRoot, 'CODEX-GLOBAL-RULES.md'), 'utf8').trim()}\n${markerEnd}`;
  const starts = guide.split(markerStart).length - 1;
  const ends = guide.split(markerEnd).length - 1;
  if (starts !== ends || starts > 1 || (starts === 1 && guide.indexOf(markerEnd) < guide.indexOf(markerStart))) {
    throw new Error('Malformed existing REA instructions block; no files were written.');
  }
  const updatedGuide = starts === 0
    ? `${guide}${guide.length && !guide.endsWith('\n') ? '\n' : ''}\n${block}\n`
    : guide.slice(0, guide.indexOf(markerStart)) + block + guide.slice(guide.indexOf(markerEnd) + markerEnd.length);
  planFile(guidePath, Buffer.from(updatedGuide, 'utf8'));

  const result = { status: apply ? 'configured' : 'planned', package_version: pkg.version, config_path: configPath,
    skill_path: targetSkill, agent_instructions_path: guidePath, changed_files: plans.map(p => p.target), backups: [],
    restart_required: plans.length > 0, live_mcp_verified: false };
  if (!apply) return result;
  const stamp = `${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomUUID().slice(0, 8)}`;
  try {
    // All destinations and complete TOML/skill plans were checked before mutation.
    for (const plan of plans) {
      const current = readRegular(plan.target);
      if (!((current === null && plan.before === null) || (current && plan.before && current.equals(plan.before)))) {
        throw new Error(`File changed during installation: ${plan.target}`);
      }
      fs.mkdirSync(path.dirname(plan.target), { recursive: true });
      let backup;
      if (current !== null) {
        backup = `${plan.target}.rea-bundle-backup.${stamp}`;
        fs.copyFileSync(plan.target, backup, fs.constants.COPYFILE_EXCL);
        if (sha256(fs.readFileSync(backup)) !== sha256(current)) throw new Error(`Backup verification failed: ${backup}`);
        result.backups.push(backup);
      }
      const stage = `${plan.target}.rea-stage-${crypto.randomUUID()}`;
      try {
        fs.writeFileSync(stage, plan.bytes, { flag: 'wx', mode: 0o600 });
        const latest = readRegular(plan.target);
        if (!((latest === null && current === null) || (latest && current && latest.equals(current)))) {
          throw new Error(`File changed before replacement: ${plan.target}`);
        }
        if (current === null) fs.linkSync(stage, plan.target);
        else fs.renameSync(stage, plan.target);
        if (!fs.readFileSync(plan.target).equals(plan.bytes)) throw new Error(`Readback failed: ${plan.target}; backup: ${backup || 'new file'}`);
      } finally {
        if (fs.existsSync(stage)) fs.unlinkSync(stage);
      }
    }
  } catch (error) {
    error.backups = result.backups;
    throw error;
  }
  return result;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    const options = JSON.parse(process.argv[2] === '--options-base64'
      ? Buffer.from(process.argv[3] || '', 'base64').toString('utf8')
      : fs.readFileSync(0, 'utf8'));
    console.log(JSON.stringify(configureCodex(options), null, 2));
  } catch (error) {
    console.error(JSON.stringify({ status: 'blocked', reason: error.message, backups: error.backups || [],
      note: 'If a write failed after earlier files changed, inspect the listed backups before retrying.' }, null, 2));
    process.exitCode = 1;
  }
}
