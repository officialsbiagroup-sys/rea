# REA for Codex — portable skill bundle (runtime 6.7.0)

এই bundle একবার Windows-এর local Codex-এর জন্য install করলে নতুন local
Codex chats এবং অন্য project folders-এ REA skill পাওয়া যাবে। শুধু ZIP attach
করলে কোনো chat-এ MCP tools, terminal access বা analysis engine তৈরি হয় না।

## কী আছে

- Published `rea-agents@6.7.0`-এর সম্পূর্ণ `reverse-engineer-anything` skill:
  `SKILL.md` এবং সব ছয়টি reference file, অপরিবর্তিত।
- অতিরিক্ত `agents/openai.yaml`: এই bundle-এর লেখা Codex display metadata।
- User-level Codex MCP/configuration installer, global agent guidance এবং backup।
- চারটি upstream REA maintainer skill, তাদের references/agent files-সহ,
  `optional-maintainer-skills/`-এ। Installer এগুলো install করে না।
- Upstream `AGENTS.md`, relevant setup docs, license এবং provenance।
- Official `smol-toml@1.9.0` parser, MIT license-সহ; installer-এর জন্য vendored।

এটি REA executable/dependencies, Node, JDK বা Ghidra-র offline distribution নয়।
REA runtime দরকার; মূল skill শুধুমাত্র instructions দেয়। Native decompilation-এর
জন্য compatible Ghidra/full JDK বা অন্য supported provider আলাদাভাবে লাগবে।

## Install — native Windows PowerShell

ZIP extract করে এই README ও installer review করুন। Extracted folder থেকে:

```powershell
.\Install-REAForCodex.ps1 -DryRun
.\Install-REAForCodex.ps1
```

এতে existing global REA 6.7.0 reuse হবে। Node 22.x >=22.19, 24.x >=24.11
বা 26+ এবং npm লাগবে। Runtime না থাকলে শুধু pinned REA package install করতে:

```powershell
.\Install-REAForCodex.ps1 -InstallMissingPackage
```

এটি npm dependencies download করতে পারে। Working REA-কে downgrade বা unrelated
tools install করবে না। অন্য runtime version থাকলে matching skill bundle ব্যবহার
করতে বলে থামবে। Existing project-local/custom REA installation থাকলে local
Codex-কে সেই installation inspect ও reuse করতে বলুন; global duplicate install
করবেন না।

Ghidra/Java আগে থেকেই MCP environment-এ configured থাকলে সেগুলো রাখা হবে।
প্রয়োজনে verified installations-এর actual paths দিন:

```powershell
.\Install-REAForCodex.ps1 `
  -GhidraInstallDir 'E:\Autonomus_Ai\reverse-engineering-lab\tools\ghidra_12.1.4_PUBLIC' `
  -JavaHome 'E:\Autonomus_Ai\reverse-engineering-lab\tools\jdk-21.0.12.1+1'
```

এগুলো আগের setup report-এর উদাহরণ; আগে actual path/version যাচাই করুন। নতুন
provider values শুধু অনুপস্থিত setting-এ যোগ হবে; existing values replace হবে না।
Provider path checks installation structure পরীক্ষা করে; real Ghidra readiness
বা decompilation সফল হয়েছে বলে ঘোষণা করে না।

## কী পরিবর্তন হবে

1. Skill: `%USERPROFILE%\.agents\skills\reverse-engineer-anything`।
2. MCP: `%CODEX_HOME%\config.toml`; variable unset/empty হলে
   `%USERPROFILE%\.codex\config.toml`। Existing REA launcher, env values, approvals
   এবং অন্য settings রাখা হবে। Registration অনুপস্থিত হলে direct Node/REA
   stdio launcher যোগ হবে। Alias/foreign/disabled registration সন্দেহ হলে থামবে।
3. Global scoped guidance: Codex home-এর existing `AGENTS.override.md`, থাকলে;
   অন্যথায় `AGENTS.md`। শুধু marked REA block append/update হবে।
4. বদলানো existing file-এর পাশে unique `.rea-bundle-backup.<timestamp>...`
   backup হবে; existing `.rea.backup` snapshots অক্ষত থাকবে। Output-এ paths থাকবে।

Installer complete TOML semantic comparison দিয়ে অন্য settings সংরক্ষণ করেছে কি না
পরীক্ষা করে। Per-tool approval table-ও রাখা হয়। প্রয়োজন ছাড়া `rea setup` চালায় না;
REA 6.7.0-এর staged setup newer Codex approval table সরিয়ে দেওয়ার সমস্যা এড়ায়।
Unknown custom skill files delete করে না। Changed bundled files-এর backup নেয়।
Malformed config, linked destination বা concurrent change পেলে থামবে।

একই state-এ আবার চালালে অপ্রয়োজনীয় edits বা backup তৈরি হবে না। Rare write failure
হলে আগে কিছু file বদলে থাকতে পারে; error-এ backup paths থাকবে। অন্ধভাবে retry না
করে current state ও backup যাচাই করুন। Automatic uninstall/rollback দেওয়া হয়নি,
কারণ পরে করা user edits overwrite করা উচিত নয়।

## Restart ও ব্যবহার

সব affected local Codex sessions থেকে বের হয়ে Codex reopen করুন। নতুন chat-এ:

```text
$reverse-engineer-anything
Use REA to statically analyze the artifact I select. Check a known MCP/provider
connection problem if present. Cite Evidence. Do not execute the target.
```

Global guidance relevant reverse-engineering requests-এ skill ব্যবহার করতে বলে;
ordinary unrelated coding-এ REA বাধ্যতামূলক নয়। Workspace instructions ও client
policy-ও প্রযোজ্য। প্রতিটি chat-এ tools connect হয়েছে কি না actual tool list থেকে
দেখতে হবে। অন্য PC, user account, remote/cloud host-এ পৃথক setup লাগবে।

REA doctor ব্যবহার করতে পারেন, কিন্তু existing newer Codex per-tool `tools` table
REA 6.7.0 doctor-এ parser defect দেখাতে পারে। Green report পেতে approval settings
delete করবেন না। Restart-এর পর live `binary_session({})` এবং actual provider
readiness আলাদাভাবে যাচাই করুন। এই bundle তৈরি করার সময় Windows installer বা
আপনার বর্তমান live MCP session execute/verify করা হয়নি।

## Integrity ও provenance

`SHA256SUMS.json`-এ সব bundle file-এর SHA-256 আছে (checksum file নিজে ছাড়া)।
`PROVENANCE.json`-এ upstream package URLs এবং verified npm SHA-512 integrity আছে।
Checksums corruption শনাক্ত করে; authorship signature নয়। Released skill version
এবং newer repository-main docs এক নয়; skill release-টির bytes অপরিবর্তিত রাখা হয়েছে।
এই bundle-এর helper scripts/metadata official upstream REA code নয়।
