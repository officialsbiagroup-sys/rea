# REA Codex bundle

This directory is a portable skill/configuration delivery bundle, not a full
REA runtime or a Windows Ghidra/JDK distribution. Start with README.md.

For a user-authorized installation, inspect Install-REAForCodex.ps1 and run its
dry-run before applying. It installs the primary skill in the user's shared
skill directory, preserves the existing REA registration, and appends a scoped
section to effective global Codex agent instructions. Never copy a whole
config.toml from another machine or replace existing tool approval policies.

The existing REA 6.7.0 setup can discard a newer Codex per-tool approval table.
Use this bundle's narrow configuration helper instead of running broad setup.
Leave Ghidra, Java, Tableau hooks and existing projects unchanged unless the
user requests their configuration separately. Check the helper's result and
restart/reconnect Codex before claiming live tool availability.

The optional-maintainer-skills directory contains upstream repository-development
skills for reference. Do not install them as ordinary reverse-engineering skills.
Upstream repository AGENTS.md is preserved under docs/upstream-source for
provenance; its maintainer rules do not configure the user's global Codex.
