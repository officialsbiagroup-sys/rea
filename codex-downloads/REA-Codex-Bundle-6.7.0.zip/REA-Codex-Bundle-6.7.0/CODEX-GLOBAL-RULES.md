## REA reverse engineering

The user-level `$reverse-engineer-anything` skill is available for reverse
engineering a user-selected shipped executable, DLL, package, ASAR, or other
supported artifact. Read that skill's instructions and relevant references
when the task needs REA. For ordinary source-repository analysis, use normal
repository tools.

Use the live REA MCP tools when connected, and respect their actual schemas
and provider availability. An installed skill or saved registration alone does
not establish a connected server. Diagnose a known connection or provider
failure; avoid repeating setup or doctor before every investigation.

Default to static analysis. Do not execute a target application unless the user
explicitly authorizes that runtime operation. Cite Evidence and distinguish
observations, inferences, limitations, and unknowns. Preserve existing client
settings, tool approvals, credentials, skills and unrelated projects. Do not
claim terminal or UI control that the current session's tools do not provide.
