[CmdletBinding()]
param(
    [switch]$DryRun,
    [switch]$InstallMissingPackage,
    [string]$GhidraInstallDir,
    [string]$JavaHome
)

$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT') { throw 'Run this installer in native Windows PowerShell.' }

$reaNode = Get-Command node.exe -ErrorAction Stop
$reaNpm = Get-Command npm.cmd -ErrorAction Stop
$reaVersionText = (& $reaNode.Source --version | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $reaVersionText -notmatch '^v\d+\.\d+\.\d+$') { throw 'Cannot read a stable Node version.' }
$reaNodeVersion = [version]$reaVersionText.Substring(1)
if (-not (($reaNodeVersion.Major -eq 22 -and $reaNodeVersion.Minor -ge 19) -or
          ($reaNodeVersion.Major -eq 24 -and $reaNodeVersion.Minor -ge 11) -or
          $reaNodeVersion.Major -ge 26)) {
    throw 'REA needs Node 22.19+ in 22.x, 24.11+ in 24.x, or 26+. Node is not installed or upgraded by this script.'
}

$reaGlobalRoot = (& $reaNpm.Source root --global | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or -not $reaGlobalRoot) { throw 'Cannot resolve the global npm package directory.' }
$reaPackageRoot = Join-Path $reaGlobalRoot 'rea-agents'
$reaPackageFile = Join-Path $reaPackageRoot 'package.json'
if (-not (Test-Path -LiteralPath $reaPackageFile -PathType Leaf)) {
    if ($DryRun -or -not $InstallMissingPackage) {
        throw 'REA 6.7.0 is not installed globally. Re-run with -InstallMissingPackage to authorize installing the pinned REA package.'
    }
    & $reaNpm.Source install --global 'rea-agents@6.7.0'
    if ($LASTEXITCODE -ne 0) { throw 'Pinned REA package installation failed.' }
}
$reaPackage = Get-Content -LiteralPath $reaPackageFile -Raw | ConvertFrom-Json
if ($reaPackage.name -ne 'rea-agents' -or $reaPackage.version -ne '6.7.0') {
    throw 'An existing REA version differs from this 6.7.0 skill bundle. No downgrade was performed; use a matching bundle.'
}

$reaCodexRoot = if ([string]::IsNullOrEmpty($env:CODEX_HOME)) { Join-Path $HOME '.codex' } else { $env:CODEX_HOME }
$reaProvider = @{}
if ($GhidraInstallDir) {
    $reaResolvedGhidra = (Resolve-Path -LiteralPath $GhidraInstallDir).ProviderPath
    if (-not (Test-Path -LiteralPath (Join-Path $reaResolvedGhidra 'support\analyzeHeadless.bat') -PathType Leaf)) {
        throw 'The supplied Ghidra directory has no support\analyzeHeadless.bat.'
    }
    $reaProvider.GHIDRA_INSTALL_DIR = $reaResolvedGhidra
}
if ($JavaHome) {
    $reaResolvedJava = (Resolve-Path -LiteralPath $JavaHome).ProviderPath
    foreach ($reaJavaTool in @('bin\java.exe', 'bin\javac.exe')) {
        if (-not (Test-Path -LiteralPath (Join-Path $reaResolvedJava $reaJavaTool) -PathType Leaf)) { throw 'The supplied JAVA_HOME is not a full JDK.' }
    }
    $reaProvider.JAVA_HOME = $reaResolvedJava
}
if ($GhidraInstallDir -and $JavaHome) { $reaProvider.REA_ANALYSIS_PROVIDER = 'ghidra' }

$reaSettings = @{
    home = [IO.Path]::GetFullPath($HOME)
    codexHome = [IO.Path]::GetFullPath($reaCodexRoot)
    reaRoot = [IO.Path]::GetFullPath($reaPackageRoot)
    nodePath = [IO.Path]::GetFullPath($reaNode.Source)
    providerEnv = $reaProvider
    apply = -not $DryRun.IsPresent
}
$reaSettingsJson = $reaSettings | ConvertTo-Json -Depth 8 -Compress
$reaSettingsEncoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($reaSettingsJson))
& $reaNode.Source (Join-Path $PSScriptRoot 'scripts\configure-codex.mjs') --options-base64 $reaSettingsEncoded
if ($LASTEXITCODE -ne 0) { throw 'Configuration was blocked; read the preceding reason and any backup paths.' }

if (-not $DryRun) {
    Write-Host 'Saved user-level skill, MCP configuration and scoped agent guidance. Restart Codex and verify the live MCP connection.'
    Write-Host 'No target was opened or executed. This installer does not verify live MCP connectivity or install Ghidra/Java.'
}
